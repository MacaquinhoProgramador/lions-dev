let produto = [
    {
        "id": 1,
        "nome": "Pc da Negativo",
        "categoria": "disfunção elétrica",
        "preco": "7,98 o quilo",
        "estoque": 500
    },
    {
        "id": 2,
        "nome": "Geladeira da Pancadasonic",
        "categoria": "Eletrodoméstico",
        "preco": 1500,
        "estoque": 10
    }
]

module.exports = { produto } 